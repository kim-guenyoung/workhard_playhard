#ifndef __sttelnode_H__
#define __sttelnode_H__

typedef struct telnode
{
	char name[20];
	char phoneNum[20];
	struct telnode* next;
}TelNode;

#endif;